# inera.core.template#2.3.0: Inera FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [Förväntade svar](expected-responses.md)
* [Testning och validering](testing.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Om](about.md)
* [Felhantering](error-handling.md)
* [Sammanfattning av artefakter](artifacts.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Användningsfall](use-cases.md)
* [Inledning](introduction.md)
* [Mappning till profiler](mappings.md)
* [Säkerhet och behörighet](security.md)
* [Versionshistorik](version-history.md)
* [Informationsunderlag](information-basis.md)
* [CapabilityStatement](capabilitystatement.md)
* [Nedladdningar](downloads.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](ImplementationGuide-inera.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
