# Nedladdningar - Inera FHIR Implementation Guide Template v2.3.0

## Nedladdningar

Följande nedladdningar är tillgängliga för denna Implementation Guide.

### Fullständigt IG-paket

Det fullständiga npm-paketet för denna IG, för användning med FHIR-validatorn och andra verktyg:

* [Paket (tgz)](https://fhir.inera.se/ig/template/package.tgz)

Se [Testning och validering](testing.md) för instruktioner om hur paketet används för att validera instanser mot profilerna i denna IG.

-------

> **Vägledning för författare:** Lägg till länkar till eventuella ytterligare artefakter som är relevanta för din IG, såsom exempelsamlingar, mappningskalkylblad eller integrationsguider.

